#!/usr/bin/env python3
"""
Telugu Voter PDF Search
Type a name in English → find matching Telugu entries across all PDFs in a folder.
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
import re
import unicodedata
import pickle
import difflib
from pathlib import Path

# ─── Dependency checks ────────────────────────────────────────────────────────

MISSING = []

try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None
    MISSING.append("pymupdf")

try:
    from indic_transliteration import sanscript
    from indic_transliteration.sanscript import transliterate as _transliterate
    HAS_TRANSLIT = True
except ImportError:
    HAS_TRANSLIT = False
    MISSING.append("indic-transliteration")

try:
    from rapidfuzz import fuzz as _rfuzz
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False  # will use built-in difflib

try:
    import numpy as _np
    from PIL import Image as _PIL_Image
    import io as _io
    import easyocr as _easyocr
    HAS_EASYOCR = True
except ImportError:
    HAS_EASYOCR = False

try:
    import pytesseract as _pytesseract
    if not HAS_EASYOCR:
        from PIL import Image as _PIL_Image
        import io as _io
    for _tp in [r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Users\{}\AppData\Local\Programs\Tesseract-OCR\tesseract.exe".format(
                    os.environ.get("USERNAME", ""))]:
        if os.path.exists(_tp):
            _pytesseract.pytesseract.tesseract_cmd = _tp
            break
    HAS_TESSERACT = "tel" in _pytesseract.get_languages()
except Exception:
    HAS_TESSERACT = False

HAS_OCR = HAS_EASYOCR or HAS_TESSERACT

try:
    import torch as _torch
    HAS_CUDA = _torch.cuda.is_available()
except Exception:
    HAS_CUDA = False

# Lazy-init EasyOCR reader (loads ML models on first use)
_ocr_reader = None

def _get_ocr_reader():
    global _ocr_reader
    if _ocr_reader is None and HAS_EASYOCR:
        device = "GPU" if HAS_CUDA else "CPU"
        print(f"[OCR] Loading EasyOCR models on {device} (first time only)...")
        _ocr_reader = _easyocr.Reader(["te", "en"], gpu=HAS_CUDA, verbose=False)
        print("[OCR] Ready.")
    return _ocr_reader

# ─── Text helpers ─────────────────────────────────────────────────────────────

def is_telugu(text: str) -> bool:
    return any('ఀ' <= c <= '౿' for c in text)


def telugu_to_roman(text: str) -> str:
    if not HAS_TRANSLIT:
        return ""
    try:
        return _transliterate(text, sanscript.TELUGU, sanscript.ITRANS)
    except Exception:
        return ""


def normalize(text: str) -> str:
    """Strip diacritics, lowercase, keep only a-z and spaces."""
    nfkd = unicodedata.normalize('NFKD', text)
    ascii_text = "".join(c for c in nfkd if not unicodedata.combining(c))
    cleaned = re.sub(r"[^a-z\s]", "", ascii_text.lower())
    return " ".join(cleaned.split())


def partial_ratio(query: str, text: str) -> int:
    """Best partial match score 0-100 of query inside text."""
    if HAS_RAPIDFUZZ:
        return int(_rfuzz.partial_ratio(query, text))
    if not query or not text:
        return 0
    n, m = len(query), len(text)
    if n > m:
        return int(difflib.SequenceMatcher(None, query, text).ratio() * 100)
    best = 0
    for i in range(m - n + 1):
        s = int(difflib.SequenceMatcher(None, query, text[i:i + n]).ratio() * 100)
        if s > best:
            best = s
        if best == 100:
            break
    return best

# ─── PDF extraction ───────────────────────────────────────────────────────────

def _page_needs_ocr(page) -> bool:
    """
    Voter PDFs from ECI store names as font glyphs with broken Unicode mapping.
    Symptom: Telugu characters are present but vowel matras are always absent.
    Real Telugu text always has combining vowel matras (U+0C3E – U+0C4E).
    """
    text = page.get_text("text")
    telugu_chars = [c for c in text if 'ఀ' <= c <= '౿']
    if not telugu_chars:
        return True   # No Telugu at all — likely scanned image
    has_matras = any('ా' <= c <= '౎' for c in telugu_chars)
    return not has_matras   # No matras = broken glyph encoding


def _ocr_page_easyocr(page) -> list:
    """EasyOCR: render page as image, return Telugu text lines."""
    reader = _get_ocr_reader()
    if reader is None:
        return []
    try:
        mat = fitz.Matrix(200 / 72, 200 / 72)
        pix = page.get_pixmap(matrix=mat)
        img_np = _np.frombuffer(pix.samples, dtype=_np.uint8).reshape(
            pix.height, pix.width, pix.n)
        if pix.n == 4:
            img_np = img_np[:, :, :3]
        results = reader.readtext(img_np)
        return [text.strip() for (_bbox, text, conf) in results
                if conf >= 0.3 and text.strip() and is_telugu(text)]
    except Exception as e:
        print(f"[EasyOCR WARN] {e}")
        return []


def _ocr_page_tesseract(page) -> list:
    """Tesseract fallback OCR."""
    try:
        from PIL import Image as _Img
        import io as _io2
        mat = fitz.Matrix(2.5, 2.5)
        pix = page.get_pixmap(matrix=mat)
        img = _Img.open(_io2.BytesIO(pix.tobytes("png")))
        raw = _pytesseract.image_to_string(img, lang="tel+eng",
                                            config="--psm 6 --oem 1")
        return [ln.strip() for ln in raw.splitlines()
                if ln.strip() and is_telugu(ln)]
    except Exception as e:
        print(f"[Tesseract WARN] {e}")
        return []


def extract_telugu_lines(pdf_path: str) -> list:
    """
    Extract Telugu text lines from a PDF.
    Auto-detects broken glyph encoding (common in Indian government voter
    PDFs) and falls back to EasyOCR / Tesseract when needed.
    Returns [(page_num, line_text)].
    """
    if fitz is None:
        return []
    lines = []
    try:
        doc = fitz.open(pdf_path)
        for page_num, page in enumerate(doc, 1):
            if HAS_OCR and _page_needs_ocr(page):
                if HAS_EASYOCR:
                    ocr_lines = _ocr_page_easyocr(page)
                else:
                    ocr_lines = _ocr_page_tesseract(page)
                for ln in ocr_lines:
                    lines.append((page_num, ln))
            else:
                text = page.get_text("text")
                for raw in text.splitlines():
                    ln = raw.strip()
                    if ln and is_telugu(ln):
                        lines.append((page_num, ln))
        doc.close()
    except Exception as e:
        print(f"[WARN] {pdf_path}: {e}")
    return lines


# ─── Voter table extraction (ECI electoral roll format) ───────────────────────
# Column headers as they appear in the standard ECI voter list PDF layout.
_TABLE_HEADERS = ["PS No", "Sl. No", "Section No", "House No", "Elector Name",
                  "Rln Type", "Relation Name", "Gender", "Age", "EPIC No"]
_TABLE_KEYS =    ["ps_no", "sl_no", "section_no", "house_no", "name",
                  "rln_type", "relation_name", "gender", "age", "epic_no"]
_NATIVE_COLS = {"ps_no", "sl_no", "section_no", "house_no", "age", "epic_no"}
_OCR_COLS = {"name", "rln_type", "relation_name", "gender"}
_TABLE_DPI = 300


def _table_native_spans(page):
    d = page.get_text("dict")
    spans = []
    for block in d["blocks"]:
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                spans.append({"text": span["text"], "x0": span["bbox"][0], "y0": span["bbox"][1],
                              "x1": span["bbox"][2], "y1": span["bbox"][3]})
    return spans


def _table_column_bounds(spans):
    """Locate header spans and compute column x-boundaries (midpoints)."""
    header_spans = [s for s in spans if s["text"].strip() in _TABLE_HEADERS]
    if len(header_spans) < 6:
        return None, None
    header_spans.sort(key=lambda s: s["x0"])
    col_x0 = [s["x0"] for s in header_spans]
    col_keys = [_TABLE_KEYS[_TABLE_HEADERS.index(s["text"].strip())] for s in header_spans]
    bounds = []
    for i in range(len(col_x0)):
        left = -1e9 if i == 0 else (col_x0[i - 1] + col_x0[i]) / 2
        right = 1e9 if i == len(col_x0) - 1 else (col_x0[i] + col_x0[i + 1]) / 2
        bounds.append((col_keys[i], left, right))
    header_y = header_spans[0]["y0"]
    return bounds, header_y


def _table_col_for_x(bounds, x0):
    for k, l, r in bounds:
        if l <= x0 < r:
            return k
    return None


def _table_group_rows(spans, header_y, bounds):
    data_spans = [s for s in spans if s["y0"] > header_y + 5]
    data_spans.sort(key=lambda s: (s["y0"], s["x0"]))
    rows, cur_row, cur_y = [], [], None
    TOL = 6
    for s in data_spans:
        if cur_y is None or abs(s["y0"] - cur_y) <= TOL:
            cur_row.append(s)
            cur_y = cur_row[0]["y0"]
        else:
            rows.append(cur_row)
            cur_row = [s]
            cur_y = s["y0"]
    if cur_row:
        rows.append(cur_row)

    row_dicts = []
    for row in rows:
        rd = {k: "" for k in _TABLE_KEYS}
        y_vals = [s["y0"] for s in row] + [s["y1"] for s in row]
        rd["_y_min"], rd["_y_max"] = min(y_vals), max(y_vals)
        for s in row:
            col = _table_col_for_x(bounds, s["x0"])
            if col in _NATIVE_COLS:
                rd[col] = (rd.get(col, "") + s["text"].strip()).strip()
        row_dicts.append(rd)
    return row_dicts


def _table_fill_ocr_columns(page, row_dicts, bounds):
    """Run one OCR pass per page and map detected Telugu text into rows/columns."""
    if not row_dicts or not HAS_EASYOCR:
        return
    reader = _get_ocr_reader()
    if reader is None:
        return
    scale = _TABLE_DPI / 72

    # Only OCR the horizontal band covering name..gender columns — skip the
    # natively-readable columns (PS No, Sl No, Section No, House No, Age,
    # EPIC No), roughly halving the pixel area EasyOCR has to process.
    ocr_bounds = [b for b in bounds if b[0] in _OCR_COLS]
    if not ocr_bounds:
        return
    page_w_pts = page.rect.width
    crop_x0_pts = max(0, min(b[1] for b in ocr_bounds))
    crop_x1_pts = min(page_w_pts, max(b[2] for b in ocr_bounds))

    mat = fitz.Matrix(scale, scale)
    clip_rect = fitz.Rect(crop_x0_pts, 0, crop_x1_pts, page.rect.height)
    pix = page.get_pixmap(matrix=mat, clip=clip_rect)
    img_np = _np.frombuffer(pix.samples, dtype=_np.uint8).reshape(pix.height, pix.width, pix.n)
    if pix.n == 4:
        img_np = img_np[:, :, :3]
    try:
        results = reader.readtext(img_np, detail=1, paragraph=False)
    except Exception as e:
        print(f"[EasyOCR WARN] {e}")
        return

    buckets = {id(rd): {c: [] for c in _OCR_COLS} for rd in row_dicts}
    for bbox, text, conf in results:
        if conf < 0.25 or not text.strip() or not is_telugu(text):
            continue
        xs = [p[0] for p in bbox]
        ys = [p[1] for p in bbox]
        px = crop_x0_pts + (sum(xs) / 4) / scale
        py = (sum(ys) / 4) / scale
        col = _table_col_for_x(bounds, px)
        if col not in _OCR_COLS:
            continue
        for rd in row_dicts:
            if rd["_y_min"] - 3 <= py <= rd["_y_max"] + 3:
                buckets[id(rd)][col].append((px, text.strip()))
                break

    for rd in row_dicts:
        for col in _OCR_COLS:
            parts = sorted(buckets[id(rd)][col], key=lambda t: t[0])
            rd[col] = " ".join(t[1] for t in parts)


def extract_voter_rows(pdf_path: str) -> list:
    """
    Extract structured voter rows from an ECI-format electoral roll PDF.
    Returns a list of dicts: {page, sl_no, name, rln_type, relation_name,
    gender, age, house_no, section_no, ps_no, epic_no}.
    Falls back to [] if the page doesn't match the expected table layout
    (caller should fall back to extract_telugu_lines in that case).
    """
    if fitz is None:
        return []
    all_rows = []
    try:
        doc = fitz.open(pdf_path)
        for page_num, page in enumerate(doc, 1):
            spans = _table_native_spans(page)
            bounds, header_y = _table_column_bounds(spans)
            if bounds is None:
                continue
            row_dicts = _table_group_rows(spans, header_y, bounds)
            row_dicts = [rd for rd in row_dicts if rd.get("sl_no", "").strip()]
            if not row_dicts:
                continue
            _table_fill_ocr_columns(page, row_dicts, bounds)
            for rd in row_dicts:
                rd.pop("_y_min", None)
                rd.pop("_y_max", None)
                rd["page"] = page_num
                if rd.get("name", "").strip():
                    all_rows.append(rd)
        doc.close()
    except Exception as e:
        print(f"[WARN] {pdf_path}: {e}")
    return all_rows

def _build_entries_for_pdf(path_str: str) -> list:
    """Extract all searchable entries for one PDF. Safe to run in a worker process."""
    path = Path(path_str)
    entries = []
    rows = extract_voter_rows(path_str)
    if rows:
        for rd in rows:
            name_text = rd.get("name", "").strip()
            roman = telugu_to_roman(name_text)
            phonetic = normalize(roman)
            if not phonetic:
                continue
            entries.append({
                "file": path.name,
                "path": path_str,
                "page": rd.get("page"),
                "text": name_text,
                "phonetic": phonetic,
                "sl_no": rd.get("sl_no", ""),
                "ps_no": rd.get("ps_no", ""),
                "section_no": rd.get("section_no", ""),
                "house_no": rd.get("house_no", ""),
                "rln_type": rd.get("rln_type", ""),
                "relation_name": rd.get("relation_name", ""),
                "gender": rd.get("gender", ""),
                "age": rd.get("age", ""),
                "epic_no": rd.get("epic_no", ""),
            })
    else:
        # Fallback: PDF doesn't match the ECI table layout — index raw Telugu lines.
        for page_num, line_text in extract_telugu_lines(path_str):
            roman = telugu_to_roman(line_text)
            phonetic = normalize(roman)
            if phonetic:
                entries.append({
                    "file": path.name,
                    "path": path_str,
                    "page": page_num,
                    "text": line_text,
                    "phonetic": phonetic,
                    "sl_no": "", "ps_no": "", "section_no": "", "house_no": "",
                    "rln_type": "", "relation_name": "", "gender": "",
                    "age": "", "epic_no": "",
                })
    return entries

# ─── Search Index ─────────────────────────────────────────────────────────────

class VoterIndex:
    def __init__(self):
        self.entries: list = []

    @property
    def size(self) -> int:
        return len(self.entries)

    def build(self, folder: str, on_progress=None) -> int:
        self.entries = []
        pdfs = sorted(Path(folder).rglob("*.pdf"))
        total = len(pdfs)
        if total == 0:
            return 0
        for i, path in enumerate(pdfs):
            if on_progress:
                on_progress(i + 1, total, path.name)
            self.entries.extend(_build_entries_for_pdf(str(path)))
        return self.size

    def build_parallel(self, folder: str, workers: int = 2, on_progress=None) -> int:
        """Same as build(), but processes multiple PDFs concurrently across
        separate worker processes (each with its own GPU-backed OCR reader)."""
        import multiprocessing as mp

        self.entries = []
        pdfs = sorted(Path(folder).rglob("*.pdf"))
        total = len(pdfs)
        if total == 0:
            return 0
        paths = [str(p) for p in pdfs]

        if workers <= 1:
            return self.build(folder, on_progress=on_progress)

        done = 0
        ctx = mp.get_context("spawn")
        with ctx.Pool(processes=workers) as pool:
            for entries in pool.imap(_build_entries_for_pdf, paths):
                self.entries.extend(entries)
                done += 1
                if on_progress:
                    on_progress(done, total, "")
        return self.size

    def search(self, query: str, threshold: int = 65, max_results: int = 300) -> list:
        q = normalize(query)
        if not q:
            return []
        results = []
        for entry in self.entries:
            score = partial_ratio(q, entry["phonetic"])
            if score >= threshold:
                results.append({**entry, "score": score})
        results.sort(key=lambda x: -x["score"])
        return results[:max_results]

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump(self.entries, f)

    def load(self, path: str) -> int:
        with open(path, "rb") as f:
            self.entries = pickle.load(f)
        return self.size

# ─── GUI ──────────────────────────────────────────────────────────────────────

BLUE   = "#1a56db"
GREEN  = "#15803d"
BG     = "#f8fafc"
CARD   = "#ffffff"
MUTED  = "#6b7280"

class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Telugu Voter Search")
        self.root.geometry("1020x700")
        self.root.minsize(800, 550)
        self.root.configure(bg=BG)

        self.idx = VoterIndex()
        self.folder_var   = tk.StringVar()
        self.search_var   = tk.StringVar()
        self.status_var   = tk.StringVar(value="Step 1 → Browse a folder with PDFs   Step 2 → Build Index   Step 3 → Search")
        self.threshold_var = tk.IntVar(value=65)
        self._row_paths: dict = {}
        self._index_file: str = ""

        self._apply_style()
        self._build_ui()

        if MISSING:
            self.root.after(300, self._warn_missing)

    # ── styling ──────────────────────────────────────────────────────────────

    def _apply_style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("Treeview",
                    font=("Segoe UI", 10),
                    rowheight=30,
                    background=CARD,
                    fieldbackground=CARD,
                    foreground="#111827")
        s.configure("Treeview.Heading",
                    font=("Segoe UI", 10, "bold"),
                    background="#e5e7eb",
                    foreground="#111827")
        s.map("Treeview", background=[("selected", "#dbeafe")])
        s.configure("TScrollbar", background="#e5e7eb", troughcolor=BG)

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self.root, bg=BLUE, pady=14)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Telugu Voter Search",
                 font=("Segoe UI", 20, "bold"), bg=BLUE, fg="white").pack()
        tk.Label(hdr,
                 text="Type a name in English  ·  Finds matching Telugu names in your PDF files",
                 font=("Segoe UI", 10), bg=BLUE, fg="#bfdbfe").pack(pady=(3, 0))

        # ── Folder row ────────────────────────────────────────────────────────
        top = tk.Frame(self.root, bg=BG, padx=16, pady=10)
        top.pack(fill="x")

        tk.Label(top, text="PDF Folder:", font=("Segoe UI", 10, "bold"), bg=BG).pack(side="left")

        tk.Entry(top, textvariable=self.folder_var,
                 font=("Segoe UI", 10), width=50,
                 relief="solid", bd=1).pack(side="left", padx=(6, 4))

        tk.Button(top, text="Browse…", command=self._browse,
                  font=("Segoe UI", 9), bg="#e5e7eb",
                  relief="flat", padx=8, cursor="hand2").pack(side="left", padx=2)

        self.idx_btn = tk.Button(top, text="⚙  Build Index",
                                  command=self._start_build,
                                  font=("Segoe UI", 10, "bold"),
                                  bg=BLUE, fg="white",
                                  relief="flat", padx=14, cursor="hand2")
        self.idx_btn.pack(side="left", padx=8)

        self.idx_lbl = tk.Label(top, text="", font=("Segoe UI", 9),
                                 bg=BG, fg=MUTED)
        self.idx_lbl.pack(side="left")

        # ── Search card ───────────────────────────────────────────────────────
        card = tk.Frame(self.root, bg=CARD, padx=16, pady=14,
                        relief="solid", bd=1)
        card.pack(fill="x", padx=16, pady=(0, 8))

        tk.Label(card, text="Search (English):",
                 font=("Segoe UI", 11, "bold"), bg=CARD).grid(row=0, column=0, sticky="w")

        self.search_entry = tk.Entry(card, textvariable=self.search_var,
                                      font=("Segoe UI", 14), width=36,
                                      relief="solid", bd=1)
        self.search_entry.grid(row=0, column=1, padx=10)
        self.search_entry.bind("<Return>", lambda _: self._search())
        self.search_entry.focus_set()

        tk.Button(card, text="Search", command=self._search,
                  font=("Segoe UI", 12, "bold"),
                  bg=GREEN, fg="white",
                  relief="flat", padx=22, cursor="hand2").grid(row=0, column=2)

        tk.Label(card,
                 text='e.g.  "Rama Rao"   "Lakshmi Devi"   "Venkata Reddy"   "Raju"',
                 font=("Segoe UI", 9), fg="#9ca3af", bg=CARD).grid(
                 row=1, column=1, sticky="w", padx=10, pady=(4, 0))

        # Sensitivity slider
        slider_frame = tk.Frame(card, bg=CARD)
        slider_frame.grid(row=0, column=3, rowspan=2, padx=(16, 0))
        tk.Label(slider_frame, text="Match sensitivity",
                 font=("Segoe UI", 8), bg=CARD, fg=MUTED).pack()
        tk.Scale(slider_frame, from_=40, to=90, orient="horizontal",
                 length=130, variable=self.threshold_var,
                 bg=CARD, highlightthickness=0,
                 font=("Segoe UI", 8), showvalue=True).pack()
        tk.Label(slider_frame, text="← Loose | Strict →",
                 font=("Segoe UI", 7), fg="#9ca3af", bg=CARD).pack()

        # ── Results panel ─────────────────────────────────────────────────────
        res = tk.Frame(self.root, bg=BG, padx=16)
        res.pack(fill="both", expand=True)

        meta_row = tk.Frame(res, bg=BG)
        meta_row.pack(fill="x", pady=(2, 4))
        self.result_lbl = tk.Label(meta_row,
                                    text="Results will appear here",
                                    font=("Segoe UI", 10), bg=BG, fg=MUTED)
        self.result_lbl.pack(side="left")
        tk.Label(meta_row,
                 text="Double-click a row to open the PDF",
                 font=("Segoe UI", 9), bg=BG, fg="#9ca3af").pack(side="right")

        cols = ("File", "Page", "Telugu Text", "Phonetic (English)", "Match %")
        widths = [170, 55, 330, 250, 70]
        anchors = ["w", "center", "w", "w", "center"]

        tree_wrap = tk.Frame(res, bg=BG)
        tree_wrap.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(tree_wrap, columns=cols, show="headings")
        for col, w, a in zip(cols, widths, anchors):
            self.tree.heading(col, text=col,
                              command=lambda c=col: self._sort(c, False))
            self.tree.column(col, width=w, anchor=a, stretch=(col == "Telugu Text"))

        vsb = ttk.Scrollbar(tree_wrap, orient="vertical",   command=self.tree.yview)
        hsb = ttk.Scrollbar(tree_wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tree_wrap.rowconfigure(0, weight=1)
        tree_wrap.columnconfigure(0, weight=1)

        self.tree.tag_configure("even", background=CARD)
        self.tree.tag_configure("odd",  background="#f9fafb")
        self.tree.bind("<Double-1>", self._open_pdf)

        # ── Progress bar (hidden until needed) ────────────────────────────────
        self.progress = ttk.Progressbar(self.root, mode="indeterminate")

        # ── Status bar ────────────────────────────────────────────────────────
        tk.Label(self.root, textvariable=self.status_var,
                 font=("Segoe UI", 9), bg="#e5e7eb", fg="#374151",
                 anchor="w", padx=12, pady=5).pack(fill="x", side="bottom")

    # ── Actions ───────────────────────────────────────────────────────────────

    def _warn_missing(self):
        libs = " ".join(MISSING)
        messagebox.showwarning(
            "Install Required Libraries",
            "The following Python libraries are missing:\n\n"
            + "\n".join(f"  • {m}" for m in MISSING)
            + f"\n\nRun this in your terminal:\n\n  pip install {libs}"
        )

    def _browse(self):
        folder = filedialog.askdirectory(title="Select folder containing Telugu PDF files")
        if not folder:
            return
        self.folder_var.set(folder)
        self._index_file = os.path.join(folder, ".voter_index.pkl")
        if os.path.exists(self._index_file):
            try:
                n = self.idx.load(self._index_file)
                self.idx_lbl.config(text=f"✓ {n:,} entries loaded")
                self.status_var.set(
                    f"Loaded saved index ({n:,} entries).  You can search now, or rebuild the index.")
                return
            except Exception:
                pass
        self.status_var.set(f"Folder selected: {folder}  ·  Click 'Build Index' to process PDFs.")

    def _start_build(self):
        folder = self.folder_var.get().strip()
        if not folder or not os.path.isdir(folder):
            messagebox.showwarning("No Folder", "Please browse and select a folder first.")
            return
        if MISSING:
            messagebox.showerror(
                "Libraries Missing",
                f"Install required libraries first:\n\n  pip install {' '.join(MISSING)}")
            return

        self.idx_btn.config(state="disabled", text="Building…")
        self.progress.pack(fill="x", padx=16, pady=2,
                           before=self.root.winfo_children()[-1])
        self.progress.start(12)

        def run():
            def cb(done, total, name):
                pct = int(done / total * 100)
                msg = f"Indexing {done}/{total}  ({pct}%)  —  {name}"
                self.root.after(0, lambda: self.status_var.set(msg))

            try:
                count = self.idx.build(folder, on_progress=cb)
                self._index_file = os.path.join(folder, ".voter_index.pkl")
                self.idx.save(self._index_file)
                self.root.after(0, lambda: self._build_done(count))
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", str(e)))
                self.root.after(0, self._build_reset)

        threading.Thread(target=run, daemon=True).start()

    def _build_done(self, count: int):
        self.progress.stop()
        self.progress.pack_forget()
        self.idx_btn.config(state="normal", text="⚙  Build Index")
        self.idx_lbl.config(text=f"✓ {count:,} entries")
        self.status_var.set(
            f"Index ready — {count:,} Telugu lines indexed.  Now type a name above and press Search.")
        if count == 0:
            messagebox.showinfo(
                "No Telugu Text Found",
                "No Telugu text was found in the PDFs.\n\n"
                "If your PDFs are scanned images, OCR support is needed (Tesseract).\n"
                "If they are digital PDFs, try opening one in a PDF viewer and check if Telugu text is selectable.")

    def _build_reset(self):
        self.progress.stop()
        self.progress.pack_forget()
        self.idx_btn.config(state="normal", text="⚙  Build Index")

    def _search(self):
        query = self.search_var.get().strip()
        if not query:
            return
        if self.idx.size == 0:
            messagebox.showinfo(
                "Index Empty",
                "Please select a folder and click 'Build Index' first.")
            return

        thresh = self.threshold_var.get()
        self.status_var.set(f"Searching for '{query}'…")
        self.root.update_idletasks()

        results = self.idx.search(query, threshold=thresh)

        for row in self.tree.get_children():
            self.tree.delete(row)
        self._row_paths.clear()

        for i, r in enumerate(results):
            iid = str(i)
            tag = "even" if i % 2 == 0 else "odd"
            self.tree.insert("", "end", iid=iid,
                             values=(r["file"], r["page"], r["text"],
                                     r["phonetic"], f"{r['score']}%"),
                             tags=(tag,))
            self._row_paths[iid] = r["path"]

        n = len(results)
        if n:
            self.result_lbl.config(
                text=f"{n} result{'s' if n != 1 else ''} found for \"{query}\"  (sensitivity {thresh}%)",
                fg="#111827")
        else:
            self.result_lbl.config(
                text=f"No results for \"{query}\".  Try lowering the sensitivity slider.",
                fg="#dc2626")
        self.status_var.set(
            f"Search complete — {n} result{'s' if n != 1 else ''} for '{query}'")

    def _open_pdf(self, event):
        iid = self.tree.focus()
        if not iid:
            return
        path = self._row_paths.get(iid)
        if path and os.path.exists(path):
            import subprocess
            subprocess.Popen(["start", "", path], shell=True)

    def _sort(self, col: str, reverse: bool):
        data = [(self.tree.set(k, col), k) for k in self.tree.get_children("")]
        # try numeric sort for % column
        try:
            data.sort(key=lambda t: int(t[0].rstrip("%")), reverse=reverse)
        except ValueError:
            data.sort(reverse=reverse)
        for idx, (_, k) in enumerate(data):
            self.tree.move(k, "", idx)
            self.tree.item(k, tags=("even" if idx % 2 == 0 else "odd",))
        self.tree.heading(col, command=lambda: self._sort(col, not reverse))


# ─── Entry point ──────────────────────────────────────────────────────────────

def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
