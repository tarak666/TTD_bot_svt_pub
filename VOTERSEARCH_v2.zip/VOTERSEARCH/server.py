"""
Telugu Voter Search — Flask API server for the Chrome extension.
Run: python server.py  (keep this window open while using the extension)
Listens on http://localhost:5005
"""
import os, sys, threading
from flask import Flask, jsonify, request
from flask_cors import CORS

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from voter_search import VoterIndex, HAS_OCR, HAS_EASYOCR, HAS_TESSERACT

app = Flask(__name__)
CORS(app)  # allow Chrome extension to call localhost

idx = VoterIndex()
_current_folder = ""

# ── build state (async so large folders don't time out) ──────────
_build = {"running": False, "done": 0, "total": 0, "count": 0, "error": None}


@app.route("/ping")
def ping():
    ocr_engine = "easyocr" if HAS_EASYOCR else ("tesseract" if HAS_TESSERACT else None)
    return jsonify({
        "ok": True,
        "entries": idx.size,
        "folder": _current_folder,
        "ocr": HAS_OCR,
        "ocr_engine": ocr_engine,
    })


@app.route("/load", methods=["POST"])
def load():
    global _current_folder
    if _build["running"]:
        # idx.entries is shared with the in-progress build thread — loading now
        # would corrupt it (stale disk data merged with live in-flight results).
        return jsonify({"error": "A build is currently in progress. Please wait for it to finish."}), 409
    folder = (request.json or {}).get("folder", "").strip()
    ipath = os.path.join(folder, ".voter_index.pkl")
    if not os.path.exists(ipath):
        return jsonify({"error": "No saved index found in that folder. Use Build Index first."}), 404
    try:
        count = idx.load(ipath)
        _current_folder = folder
        return jsonify({"count": count, "folder": folder})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/build", methods=["POST"])
def build():
    global _current_folder
    if _build["running"]:
        return jsonify({"error": "Build already in progress"}), 409
    folder = (request.json or {}).get("folder", "").strip()
    if not folder or not os.path.isdir(folder):
        return jsonify({"error": f"Folder not found: {folder}"}), 400
    # Default to 1: on a single GPU, CUDA serializes work across processes anyway,
    # so extra workers add memory pressure without real speedup (measured).
    workers = int((request.json or {}).get("workers", 1))

    _current_folder = folder
    _build.update(running=True, done=0, total=0, count=0, error=None)

    def run():
        def cb(done, total, _name):
            _build["done"] = done
            _build["total"] = total
        try:
            count = idx.build_parallel(folder, workers=workers, on_progress=cb)
            idx.save(os.path.join(folder, ".voter_index.pkl"))
            _build["count"] = count
        except Exception as e:
            _build["error"] = str(e)
        finally:
            _build["running"] = False

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"started": True, "workers": workers})


@app.route("/build_status")
def build_status():
    return jsonify(_build)


@app.route("/to_telugu", methods=["POST"])
def to_telugu():
    """Convert English phonetic input to Telugu script (ITRANS → Telugu)."""
    from voter_search import normalize
    try:
        from indic_transliteration import sanscript
        from indic_transliteration.sanscript import transliterate
    except ImportError:
        return jsonify({"telugu": "", "itrans": ""})

    text = (request.json or {}).get("text", "").strip()
    if not text:
        return jsonify({"telugu": "", "itrans": ""})

    # Try two ITRANS variants: user's exact input + one with long-vowel heuristic
    def auto_itrans(word):
        """Guess proper ITRANS from English phonetic (handle common patterns)."""
        w = word
        # Common English spellings → ITRANS equivalents
        w = w.replace("oo", "U").replace("ee", "I").replace("aa", "A")
        w = w.replace("sh", "sh").replace("th", "t").replace("kh", "K")
        # First vowel 'a' in most Telugu names is long (A)
        w = w[:1] + w[1:]  # preserve first char
        import re
        # 'a' at start of word before a consonant cluster → 'A'
        w = re.sub(r'^ra', 'rA', w)
        w = re.sub(r'^la', 'lA', w)
        w = re.sub(r'^va', 'vA', w)
        w = re.sub(r'^ka', 'kA', w)
        w = re.sub(r'^sa', 'sA', w)
        w = re.sub(r'^ma', 'mA', w)
        w = re.sub(r'^na', 'nA', w)
        w = re.sub(r'^pa', 'pA', w)
        w = re.sub(r'^ba', 'bA', w)
        w = re.sub(r'^ga', 'gA', w)
        w = re.sub(r'^ta', 'tA', w)
        w = re.sub(r'^da', 'dA', w)
        w = re.sub(r'^ha', 'hA', w)
        return w

    words = text.split()
    itrans_words = [auto_itrans(w) for w in words]
    itrans = " ".join(itrans_words)

    try:
        telugu = transliterate(itrans, sanscript.ITRANS, sanscript.TELUGU)
        # Also show exact conversion for comparison
        telugu_exact = transliterate(text, sanscript.ITRANS, sanscript.TELUGU)
        return jsonify({
            "telugu": telugu,
            "telugu_exact": telugu_exact,
            "itrans": itrans,
        })
    except Exception as e:
        return jsonify({"telugu": "", "itrans": "", "error": str(e)})


@app.route("/search", methods=["POST"])
def search():
    data = request.json or {}
    query = data.get("query", "").strip()
    threshold = int(data.get("threshold", 65))

    if not query:
        return jsonify({"results": [], "total": 0})
    if idx.size == 0:
        return jsonify({"error": "Index is empty. Set folder and build/load index first."}), 400

    results = idx.search(query, threshold=threshold)
    clean = [
        {"file": r["file"], "page": r["page"],
         "text": r["text"], "phonetic": r["phonetic"], "score": r["score"],
         "sl_no": r.get("sl_no", ""), "house_no": r.get("house_no", ""),
         "rln_type": r.get("rln_type", ""), "relation_name": r.get("relation_name", ""),
         "gender": r.get("gender", ""), "age": r.get("age", ""),
         "epic_no": r.get("epic_no", "")}
        for r in results[:100]
    ]
    return jsonify({"results": clean, "total": len(results)})


if __name__ == "__main__":
    print("=" * 50)
    print("  Telugu Voter Search — API Server")
    print("  Running on http://localhost:5005")
    print("  Keep this window open while using")
    print("  the Chrome extension.")
    print("=" * 50)
    app.run(host="127.0.0.1", port=5005, debug=False)
