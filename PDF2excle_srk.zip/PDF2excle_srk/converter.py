from deep_translator import GoogleTranslator

# Reusable translator instance
translator = GoogleTranslator(source='te', target='en')

# Electoral Roll Specific Mappings
RLN_TYPE_MAP = {
    "భ": "Husband",
    "తం": "Father",
    "త": "Mother",
    "భార్య": "Wife"
}

GENDER_MAP = {
    "స్త్రీ": "Female",
    "పు": "Male"
}

def convert_telugu_phrase_to_english(telugu_text):
    if not telugu_text:
        return ""
    try:
        # Use Google Translate API (via deep-translator)
        # This handles Urdu names written in Telugu script correctly (e.g. యూసూఫ్ -> Yusuf)
        english_text = translator.translate(telugu_text)
        return english_text.title()
    except Exception as e:
        print(f"Translation error: {e}")
        return telugu_text

def convert_row_to_english(telugu_row):
    """
    Takes a dictionary (row) containing Telugu data and returns a new dictionary
    where the Telugu content has been intelligently translated to English.
    """
    english_row = telugu_row.copy()
    
    # Translate Names
    for col in ["Elector Name", "Relation Name"]:
        if col in english_row and english_row[col]:
            english_row[col] = convert_telugu_phrase_to_english(english_row[col])
            
    # Map Relation Type exactly if it matches known abbreviations
    if "Rln Type" in english_row and english_row["Rln Type"]:
        val = english_row["Rln Type"].strip()
        if val in RLN_TYPE_MAP:
            english_row["Rln Type"] = RLN_TYPE_MAP[val]
        else:
            english_row["Rln Type"] = convert_telugu_phrase_to_english(val)
            
    # Map Gender exactly
    if "Gender" in english_row and english_row["Gender"]:
        val = english_row["Gender"].strip()
        if val in GENDER_MAP:
            english_row["Gender"] = GENDER_MAP[val]
        else:
            english_row["Gender"] = convert_telugu_phrase_to_english(val)
            
    return english_row
