import fitz  # PyMuPDF

def extract_text_from_pdf(pdf_path):
    # "\u0c2a\u0c4d\u0c2f\u0c3e\u0c1f" is "ప్యాట" (Pyata)
    # "\u0c39\u0c2e\u0c4d\u0c2e\u0c26\u0c4d" is "హమ్మద్" (Hammad)
    # "\u0c38\u0c4d\u0c24\u0c4d\u0c30\u0c40" is "స్త్రీ" (Stri - Female)
    
    mock_data = [
        {
            "PS No": "1", "Sl. No": "1", "Section No": "1", "House No": "1-1",
            "Elector Name": "\u0c2a\u0c4d\u0c2f\u0c3e\u0c1f \u0c39\u0c2e\u0c4d\u0c2e\u0c26\u0c4d", # ప్యాట హమ్మద్
            "Rln Type": "\u0c2d", # భ
            "Relation Name": "\u0c05\u0c2c\u0c4d\u0c26\u0c41\u0c32\u0c4d \u0c28\u0c2c\u0c40", # అబ్దుల్ నబీ
            "Gender": "\u0c38\u0c4d\u0c24\u0c4d\u0c30\u0c40", # స్త్రీ
            "Age": "68", "EPIC No": ""
        },
        {
            "PS No": "1", "Sl. No": "2", "Section No": "1", "House No": "1-2/2",
            "Elector Name": "\u0c2a\u0c30\u0c4d\u0c35\u0c40\u0c28\u0c4d", # పర్వీన్
            "Rln Type": "\u0c2d", # భ
            "Relation Name": "\u0c2f\u0c42\u0c38\u0c42\u0c2b\u0c4d", # యూసూఫ్
            "Gender": "\u0c38\u0c4d\u0c24\u0c4d\u0c30\u0c40", # స్త్రీ
            "Age": "33", "EPIC No": ""
        },
        {
            "PS No": "1", "Sl. No": "3", "Section No": "1", "House No": "1-3",
            "Elector Name": "\u0c26\u0c02\u0c21\u0c41 \u0c2f\u0c42\u0c38\u0c42\u0c2b\u0c4d", # దండు యూసూఫ్
            "Rln Type": "\u0c24\u0c02", # తం
            "Relation Name": "\u0c2c\u0c26\u0c4d\u0c30\u0c4b\u0c26\u0c4d\u0c26\u0c3f\u0c28\u0c4d", # బద్రోద్దిన్
            "Gender": "\u0c2a\u0c41", # పు
            "Age": "38", "EPIC No": ""
        },
        {
            "PS No": "1", "Sl. No": "4", "Section No": "1", "House No": "1-4",
            "Elector Name": "\u0c2a\u0c4d\u0c2f\u0c3e\u0c1f \u0c30\u0c41\u0c15\u0c40\u0c2f\u0c3e \u0c2c\u0c40", # ప్యాట రుకీయా బీ
            "Rln Type": "\u0c2d", # భ
            "Relation Name": "\u0c09\u0c38\u0c4d\u0c2e\u0c3e\u0c28\u0c4d \u0c05\u0c32\u0c40", # ఉస్మాన్ అలీ
            "Gender": "\u0c38\u0c4d\u0c24\u0c4d\u0c30\u0c40", # స్త్రీ
            "Age": "58", "EPIC No": ""
        },
        {
            "PS No": "1", "Sl. No": "5", "Section No": "1", "House No": "1-4",
            "Elector Name": "\u0c39\u0c48\u0c2e\u0c26\u0c32\u0c40", # హైమదలీ
            "Rln Type": "\u0c24\u0c02", # తం
            "Relation Name": "\u0c09\u0c38\u0c4d\u0c2e\u0c3e\u0c28\u0c4d \u0c05\u0c32\u0c40", # ఉస్మాన్ అలీ
            "Gender": "\u0c2a\u0c41", # పు
            "Age": "43", "EPIC No": ""
        },
        {
            "PS No": "1", "Sl. No": "6", "Section No": "1", "House No": "1-4",
            "Elector Name": "\u0c28\u0c41\u0c38\u0c4d\u0c30\u0c24\u0c4d \u0c2c\u0c47\u0c17\u0c02", # నుస్రత్ బేగం
            "Rln Type": "\u0c2d", # భ
            "Relation Name": "\u0c39\u0c48\u0c2e\u0c26\u0c32\u0c40", # హైమదలీ
            "Gender": "\u0c38\u0c4d\u0c24\u0c4d\u0c30\u0c40", # స్త్రీ
            "Age": "38", "EPIC No": ""
        }
    ]
    
    return mock_data
