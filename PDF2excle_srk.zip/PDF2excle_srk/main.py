import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os

from pdf_processor import extract_text_from_pdf
from converter import convert_row_to_english
from excel_exporter import export_english_only, export_bilingual

# Configuration
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("PDF -> Excel | Telugu + English Bilingual")
        self.geometry("1200x800")
        
        # State
        self.pdf_path = None
        self.telugu_data = []
        self.english_data = []
        self.current_view = "English" # "English" or "Telugu"
        self.columns = ["PS No", "Sl. No", "Section No", "House No", "Elector Name", "Rln Type", "Relation Name", "Gender", "Age", "EPIC No"]

        self._build_ui()

    def _build_ui(self):
        # Top Bar Frame
        self.top_bar = ctk.CTkFrame(self, height=50, corner_radius=0, fg_color="#1e2330")
        self.top_bar.pack(fill="x", side="top")
        
        # Title
        title_label = ctk.CTkLabel(self.top_bar, text="⚡ PDF ➔ Excel | Telugu + English Bilingual", font=ctk.CTkFont(size=18, weight="bold"), text_color="white")
        title_label.pack(side="left", padx=20, pady=10)
        
        # Controls in Top Bar
        self.upload_btn = ctk.CTkButton(self.top_bar, text="📁 Upload PDF", command=self.upload_pdf, width=120, fg_color="#3b76e1")
        self.upload_btn.pack(side="right", padx=20, pady=10)
        
        self.llm_check = ctk.CTkCheckBox(self.top_bar, text="LLM Names llama3.2")
        self.llm_check.pack(side="right", padx=20)
        
        self.ocr_check = ctk.CTkCheckBox(self.top_bar, text="OCR ready")
        self.ocr_check.select()
        self.ocr_check.pack(side="right", padx=20)
        
        # Preview Toggle Bar
        self.toggle_bar = ctk.CTkFrame(self, height=40, corner_radius=0, fg_color="#151923")
        self.toggle_bar.pack(fill="x")
        
        preview_label = ctk.CTkLabel(self.toggle_bar, text="Preview: ")
        preview_label.pack(side="left", padx=(20, 5), pady=5)
        
        self.radio_var = tk.StringVar(value="English")
        
        self.radio_en = ctk.CTkRadioButton(self.toggle_bar, text="English (transliterated)", variable=self.radio_var, value="English", command=self.update_table_view)
        self.radio_en.pack(side="left", padx=10)
        
        self.radio_te = ctk.CTkRadioButton(self.toggle_bar, text="Telugu (original)", variable=self.radio_var, value="Telugu", command=self.update_table_view)
        self.radio_te.pack(side="left", padx=10)
        
        # Status Label just below toggle
        self.status_bar_top = ctk.CTkLabel(self.toggle_bar, text="0 records", text_color="gray", font=ctk.CTkFont(size=11))
        self.status_bar_top.pack(side="right", padx=20)
        
        # Path Label
        self.path_label = ctk.CTkLabel(self, text="No file selected...", text_color="gray", anchor="w")
        self.path_label.pack(fill="x", padx=20, pady=5)

        # Table Frame
        self.table_frame = ctk.CTkFrame(self, corner_radius=0)
        self.table_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Configure Treeview style
        style = ttk.Style(self)
        style.theme_use("default")
        style.configure("Treeview", 
                        background="#f9f9f9", 
                        foreground="black", 
                        rowheight=25, 
                        fieldbackground="#f9f9f9",
                        font=("Nirmala UI", 10))
        style.map("Treeview", background=[('selected', '#dce8f7')], foreground=[('selected', 'black')])
        style.configure("Treeview.Heading", font=("Nirmala UI", 10, "bold"), background="#20293b", foreground="white", padding=5)

        # Create Treeview
        self.tree = ttk.Treeview(self.table_frame, columns=self.columns, show="headings")
        
        # Set column widths and headings
        widths = [50, 50, 80, 80, 200, 100, 200, 80, 50, 120]
        for i, col in enumerate(self.columns):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=widths[i], anchor="center" if col not in ["Elector Name", "Relation Name"] else "w")
            
        # Scrollbars for Treeview
        y_scroll = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.tree.yview)
        y_scroll.pack(side="right", fill="y")
        x_scroll = ttk.Scrollbar(self.table_frame, orient="horizontal", command=self.tree.xview)
        x_scroll.pack(side="bottom", fill="x")
        self.tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
        
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_row_select)

        # Bottom Details Pane
        self.details_frame = ctk.CTkFrame(self, height=120, corner_radius=0, fg_color="#20293b")
        self.details_frame.pack(fill="x", padx=10, pady=(5,0))
        
        self.details_title = ctk.CTkLabel(self.details_frame, text="Click a row ➔ Telugu original (teal) ➔ English (purple)", font=ctk.CTkFont(family="Nirmala UI", size=12, slant="italic"), text_color="gray")
        self.details_title.grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=5)
        
        # Detail labels
        self.d_elector_lbl = ctk.CTkLabel(self.details_frame, text="Elector Name:", text_color="gray")
        self.d_elector_lbl.grid(row=1, column=0, sticky="w", padx=10, pady=2)
        self.d_elector_val = ctk.CTkLabel(self.details_frame, text="---", text_color="white", font=ctk.CTkFont(family="Nirmala UI", size=12))
        self.d_elector_val.grid(row=1, column=1, sticky="w", padx=10, pady=2)
        
        self.d_rel_lbl = ctk.CTkLabel(self.details_frame, text="Relation Name:", text_color="gray")
        self.d_rel_lbl.grid(row=1, column=2, sticky="w", padx=10, pady=2)
        self.d_rel_val = ctk.CTkLabel(self.details_frame, text="---", text_color="white", font=ctk.CTkFont(family="Nirmala UI", size=12))
        self.d_rel_val.grid(row=1, column=3, sticky="w", padx=10, pady=2)

        self.d_rln_lbl = ctk.CTkLabel(self.details_frame, text="Rln Type:", text_color="gray")
        self.d_rln_lbl.grid(row=2, column=0, sticky="w", padx=10, pady=2)
        self.d_rln_val = ctk.CTkLabel(self.details_frame, text="---", text_color="white", font=ctk.CTkFont(family="Nirmala UI", size=12))
        self.d_rln_val.grid(row=2, column=1, sticky="w", padx=10, pady=2)
        
        self.d_gender_lbl = ctk.CTkLabel(self.details_frame, text="Gender:", text_color="gray")
        self.d_gender_lbl.grid(row=2, column=2, sticky="w", padx=10, pady=2)
        self.d_gender_val = ctk.CTkLabel(self.details_frame, text="---", text_color="white", font=ctk.CTkFont(family="Nirmala UI", size=12))
        self.d_gender_val.grid(row=2, column=3, sticky="w", padx=10, pady=2)

        # Footer Frame
        self.footer = ctk.CTkFrame(self, height=50, corner_radius=0, fg_color="#ebeced")
        self.footer.pack(fill="x", side="bottom")
        
        self.footer_status = ctk.CTkLabel(self.footer, text="0 records [fast] — click row to see Telugu ↔ English below — Excel has both columns", text_color="gray", font=ctk.CTkFont(size=11))
        self.footer_status.pack(side="left", padx=20, pady=10)
        
        self.export_bi_btn = ctk.CTkButton(self.footer, text="📊 Export Bilingual", command=self.export_bi, fg_color="#0ea5e9", state="disabled")
        self.export_bi_btn.pack(side="right", padx=10, pady=10)
        
        self.export_en_btn = ctk.CTkButton(self.footer, text="📊 Export English Only", command=self.export_en, fg_color="#10b981", state="disabled")
        self.export_en_btn.pack(side="right", padx=10, pady=10)

    def upload_pdf(self):
        filetypes = (('PDF files', '*.pdf'), ('All files', '*.*'))
        filename = filedialog.askopenfilename(title='Open PDF file', initialdir=os.getcwd(), filetypes=filetypes)
        
        if filename:
            self.pdf_path = filename
            self.path_label.configure(text=filename)
            self.footer_status.configure(text="Processing...", text_color="orange")
            self.upload_btn.configure(state="disabled")
            
            threading.Thread(target=self._process_pdf, daemon=True).start()

    def _process_pdf(self):
        try:
            # Extract basic telugu dicts
            self.telugu_data = extract_text_from_pdf(self.pdf_path)
            
            # Convert to english
            self.english_data = [convert_row_to_english(row) for row in self.telugu_data]
            
            self.after(0, self._process_complete)
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("Error", str(e)))
            self.after(0, lambda: self.upload_btn.configure(state="normal"))

    def _process_complete(self):
        self.upload_btn.configure(state="normal")
        self.export_en_btn.configure(state="normal")
        self.export_bi_btn.configure(state="normal")
        
        count = len(self.telugu_data)
        self.status_bar_top.configure(text=f"{count} records")
        self.footer_status.configure(text=f"Done [fast] — {count} records.", text_color="black")
        
        self.update_table_view()

    def update_table_view(self):
        # Clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        data_to_show = self.english_data if self.radio_var.get() == "English" else self.telugu_data
        
        # Insert alternating tags for row coloring
        for i, row in enumerate(data_to_show):
            values = [row.get(col, "") for col in self.columns]
            tag = 'even' if i % 2 == 0 else 'odd'
            self.tree.insert("", "end", iid=str(i), values=values, tags=(tag,))
            
        self.tree.tag_configure('even', background='#ffffff')
        self.tree.tag_configure('odd', background='#f9f9f9')

    def on_row_select(self, event):
        selected = self.tree.selection()
        if not selected:
            return
            
        index = int(selected[0])
        t_row = self.telugu_data[index]
        e_row = self.english_data[index]
        
        # Update Details Pane
        # Format: Telugu ➔ English
        self.d_elector_val.configure(text=f"{t_row.get('Elector Name','')} ➔ {e_row.get('Elector Name','')}")
        self.d_rel_val.configure(text=f"{t_row.get('Relation Name','')} ➔ {e_row.get('Relation Name','')}")
        self.d_rln_val.configure(text=f"{t_row.get('Rln Type','')} ➔ {e_row.get('Rln Type','')}")
        self.d_gender_val.configure(text=f"{t_row.get('Gender','')} ➔ {e_row.get('Gender','')}")

    def export_en(self):
        if not self.english_data: return
        filetypes = (('Excel files', '*.xlsx'), ('All files', '*.*'))
        filename = filedialog.asksaveasfilename(title='Save English Export', initialdir=os.getcwd(), filetypes=filetypes, defaultextension=".xlsx")
        if filename:
            try:
                export_english_only(self.english_data, filename)
                messagebox.showinfo("Success", "English Data Exported!")
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def export_bi(self):
        if not self.telugu_data or not self.english_data: return
        filetypes = (('Excel files', '*.xlsx'), ('All files', '*.*'))
        filename = filedialog.asksaveasfilename(title='Save Bilingual Export', initialdir=os.getcwd(), filetypes=filetypes, defaultextension=".xlsx")
        if filename:
            try:
                export_bilingual(self.telugu_data, self.english_data, filename)
                messagebox.showinfo("Success", "Bilingual Data Exported!")
            except Exception as e:
                messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    app = App()
    app.mainloop()
