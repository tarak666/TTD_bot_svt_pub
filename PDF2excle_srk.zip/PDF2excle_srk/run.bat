@echo off
title PDF to Excel Setup

:: Change directory to where the bat file is located
cd /d "%~dp0"

echo ===================================================
echo Setting up PDF to Excel Converter for Windows 11
echo ===================================================
echo.

echo Installing required Python modules...
pip install -r requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Failed to install requirements!
    echo Please make sure Python is installed and added to your system PATH.
    pause
    exit /b
)

echo.
echo Creating Desktop Shortcut...
powershell -Command "$wshell = New-Object -ComObject WScript.Shell; $desktop = [Environment]::GetFolderPath('Desktop'); $shortcut = $wshell.CreateShortcut(\"$desktop\PDF to Excel Converter.lnk\"); $shortcut.TargetPath = 'pythonw.exe'; $shortcut.Arguments = '\"' + (Get-Location).Path + '\main.py\"'; $shortcut.WorkingDirectory = (Get-Location).Path; $shortcut.WindowStyle = 1; $shortcut.Save()"

echo.
echo ===================================================
echo Setup Complete!
echo A shortcut named "PDF to Excel Converter" has been 
echo placed on your Desktop.
echo ===================================================
echo.
echo Starting the application...
start pythonw main.py
