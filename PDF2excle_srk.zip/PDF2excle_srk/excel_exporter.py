import pandas as pd

def export_english_only(english_data, output_path):
    """
    Exports only the English transliterated data.
    """
    if not english_data:
        raise ValueError("No data to export.")
    df = pd.DataFrame(english_data)
    df.to_excel(output_path, index=False)
    return True

def export_bilingual(telugu_data, english_data, output_path):
    """
    Exports both Telugu and English data, column by column.
    E.g., "Elector Name (Telugu)", "Elector Name (English)"
    """
    if not telugu_data or not english_data:
        raise ValueError("No data to export.")
        
    combined_data = []
    
    for t_row, e_row in zip(telugu_data, english_data):
        row = {}
        # Assuming the keys are the same
        for key in t_row.keys():
            if key in ["Elector Name", "Relation Name"]:
                row[f"{key} (Telugu)"] = t_row[key]
                row[f"{key} (English)"] = e_row[key]
            else:
                row[key] = t_row[key] # Shared columns (like Age, Gender, etc)
        combined_data.append(row)
        
    df = pd.DataFrame(combined_data)
    df.to_excel(output_path, index=False)
    return True
