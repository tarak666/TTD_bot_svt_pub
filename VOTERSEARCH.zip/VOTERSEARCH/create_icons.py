"""Generates the Chrome extension icons using PyMuPDF."""
import fitz, os

def make_icon(size, out_path):
    doc = fitz.open()
    page = doc.new_page(width=size, height=size)
    r = size
    # Blue rounded background
    page.draw_rect(fitz.Rect(0, 0, r, r), color=None, fill=(0.11, 0.33, 0.86))
    # White search symbol (circle + handle)
    cx, cy, cr = r * 0.42, r * 0.42, r * 0.24
    page.draw_circle((cx, cy), cr,  color=(1,1,1), fill=None, width=r*0.10)
    x1, y1 = cx + cr * 0.7, cy + cr * 0.7
    x2, y2 = r * 0.82, r * 0.82
    page.draw_line((x1, y1), (x2, y2), color=(1,1,1), width=r*0.10)
    pix = page.get_pixmap(dpi=72)
    pix.save(out_path)
    doc.close()

os.makedirs("extension/icons", exist_ok=True)
for sz in [16, 48, 128]:
    make_icon(sz, f"extension/icons/icon{sz}.png")
    print(f"Created icon{sz}.png")
print("Icons ready.")
