#!/usr/bin/env python3
"""
Native Messaging Host for the Telugu Voter Search Chrome extension.
Lets the extension start/stop/check the local Flask server without
the user manually running a .bat file.

Chrome launches this script and talks to it over stdin/stdout using
the native messaging protocol: each message is a 4-byte little-endian
length prefix followed by that many bytes of UTF-8 JSON.
"""
import sys
import os
import json
import struct
import subprocess
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SERVER_PY = os.path.join(BASE_DIR, "server.py")
PID_FILE = os.path.join(BASE_DIR, ".server.pid")
LOG_FILE = os.path.join(BASE_DIR, ".host.log")

try:
    import urllib.request
except ImportError:
    urllib = None


def log(msg):
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {msg}\n")
    except Exception:
        pass


def read_message():
    raw_len = sys.stdin.buffer.read(4)
    if not raw_len or len(raw_len) < 4:
        return None
    msg_len = struct.unpack("<I", raw_len)[0]
    raw_msg = sys.stdin.buffer.read(msg_len)
    return json.loads(raw_msg.decode("utf-8"))


def send_message(obj):
    data = json.dumps(obj).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(data)))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def _ping_server(timeout=1.5):
    if urllib is None:
        return None
    try:
        with urllib.request.urlopen("http://localhost:5005/ping", timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _read_pid():
    if not os.path.exists(PID_FILE):
        return None
    try:
        with open(PID_FILE) as f:
            return int(f.read().strip())
    except Exception:
        return None


def _pid_alive(pid):
    if pid is None:
        return False
    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}"],
            capture_output=True, text=True, timeout=5,
        )
        return str(pid) in result.stdout
    except Exception:
        return False


def cmd_status():
    ping = _ping_server()
    if ping:
        return {"running": True, "entries": ping.get("entries", 0),
                "folder": ping.get("folder", ""), "ocr": ping.get("ocr", False),
                "ocr_engine": ping.get("ocr_engine")}
    pid = _read_pid()
    if pid and _pid_alive(pid):
        return {"running": True, "starting": True}
    return {"running": False}


def cmd_start():
    existing = cmd_status()
    if existing.get("running"):
        return {"ok": True, "already_running": True}

    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    exe = pyw if os.path.exists(pyw) else sys.executable

    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP

    try:
        proc = subprocess.Popen(
            [exe, SERVER_PY],
            cwd=BASE_DIR,
            creationflags=creationflags,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        with open(PID_FILE, "w") as f:
            f.write(str(proc.pid))
        log(f"Started server, pid={proc.pid}")
        return {"ok": True, "pid": proc.pid}
    except Exception as e:
        log(f"Start failed: {e}")
        return {"ok": False, "error": str(e)}


def cmd_stop():
    pid = _read_pid()
    if pid is None:
        return {"ok": True, "already_stopped": True}
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       capture_output=True, timeout=10)
        log(f"Stopped server, pid={pid}")
    except Exception as e:
        log(f"Stop failed: {e}")
        return {"ok": False, "error": str(e)}
    finally:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    return {"ok": True}


def main():
    log("Host started")
    while True:
        try:
            msg = read_message()
        except Exception as e:
            log(f"Read error: {e}")
            break
        if msg is None:
            break
        cmd = msg.get("cmd")
        log(f"Received cmd={cmd}")
        if cmd == "status":
            send_message(cmd_status())
        elif cmd == "start":
            send_message(cmd_start())
        elif cmd == "stop":
            send_message(cmd_stop())
        else:
            send_message({"ok": False, "error": f"Unknown cmd: {cmd}"})
    log("Host exiting")


if __name__ == "__main__":
    main()
