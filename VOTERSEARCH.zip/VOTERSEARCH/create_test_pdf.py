"""
Creates a sample Telugu voter list PDF for testing the search app.
Run: python create_test_pdf.py
"""
import fitz

sample_voters = [
    "1. రామ రావు, వయస్సు: 45, పురుషుడు, గృహ సంఖ్య: 12-3",
    "2. లక్ష్మి దేవి, వయస్సు: 38, స్త్రీ, గృహ సంఖ్య: 12-3",
    "3. వెంకట రెడ్డి, వయస్సు: 52, పురుషుడు, గృహ సంఖ్య: 14-1",
    "4. సీత మహాలక్ష్మి, వయస్సు: 30, స్త్రీ, గృహ సంఖ్య: 15-2",
    "5. కృష్ణ మూర్తి, వయస్సు: 60, పురుషుడు, గృహ సంఖ్య: 16-4",
    "6. నాగరాజు, వయస్సు: 28, పురుషుడు, గృహ సంఖ్య: 17-5",
    "7. సుబ్రమణ్యం, వయస్సు: 44, పురుషుడు, గృహ సంఖ్య: 18-1",
    "8. పద్మావతి, వయస్సు: 35, స్త్రీ, గృహ సంఖ్య: 19-2",
    "9. అంజనేయులు, వయస్సు: 55, పురుషుడు, గృహ సంఖ్య: 20-3",
    "10. సరస్వతి, వయస్సు: 42, స్త్రీ, గృహ సంఖ్య: 21-6",
]

doc = fitz.open()
page = doc.new_page()

# Title
page.insert_text((50, 50), "మతదారుల జాబితా - వార్డు 5", fontsize=16)
page.insert_text((50, 75), "Voter List - Ward 5 (Test File)", fontsize=12)

# Voters
y = 120
for line in sample_voters:
    page.insert_text((50, y), line, fontsize=11)
    y += 28

import os
out = os.path.join(os.path.dirname(__file__), "test_voters", "ward5_voters.pdf")
os.makedirs(os.path.dirname(out), exist_ok=True)
doc.save(out)
doc.close()
print(f"Test PDF created: {out}")
print("Now open the voter_search app, browse to the 'test_voters' folder, and build the index.")
