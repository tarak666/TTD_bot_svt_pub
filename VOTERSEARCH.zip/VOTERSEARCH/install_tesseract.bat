@echo off
echo ============================================================
echo  Installing Tesseract OCR with Telugu language support
echo  This is needed because voter PDFs use image-based fonts.
echo ============================================================
echo.

echo Step 1: Installing Tesseract via winget...
winget install --id UB-Mannheim.TesseractOCR -e --silent
if %errorlevel% neq 0 (
    echo.
    echo winget install failed. Trying Chocolatey...
    choco install tesseract -y 2>nul
)

echo.
echo Step 2: Installing Telugu language pack...
set TESSDATA=C:\Program Files\Tesseract-OCR\tessdata

if not exist "%TESSDATA%" (
    set TESSDATA=C:\Users\%USERNAME%\AppData\Local\Programs\Tesseract-OCR\tessdata
)

echo Downloading Telugu trained data to: %TESSDATA%
powershell -Command "& { try { Invoke-WebRequest -Uri 'https://github.com/tesseract-ocr/tessdata/raw/main/tel.traineddata' -OutFile '%TESSDATA%\tel.traineddata' -UseBasicParsing; Write-Host 'Telugu pack downloaded OK' } catch { Write-Host 'Download failed - see manual instructions below' } }"

echo.
echo Step 3: Installing Python wrapper...
pip install pytesseract pdf2image --quiet

echo.
echo Step 4: Verifying...
tesseract --list-langs 2>nul | findstr tel
if %errorlevel% equ 0 (
    echo SUCCESS: Tesseract + Telugu are ready!
) else (
    echo.
    echo ============================================================
    echo  MANUAL INSTALL (if above failed):
    echo  1. Download Tesseract from:
    echo     https://github.com/UB-Mannheim/tesseract/wiki
    echo     (download tesseract-ocr-w64-setup-X.X.X.exe)
    echo.
    echo  2. Run the installer, select "Additional language data"
    echo     and check "Telugu" during installation.
    echo.
    echo  3. Run: pip install pytesseract pdf2image
    echo ============================================================
)

echo.
pause
