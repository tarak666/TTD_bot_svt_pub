@echo off
"C:\Users\thyderab\AppData\Local\Programs\Python\Python311\pythonw.exe" "D:\New folder\VOTERSEARCH\host.py"
