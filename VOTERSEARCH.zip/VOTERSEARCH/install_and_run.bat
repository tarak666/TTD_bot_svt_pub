@echo off
echo ============================================
echo  Telugu Voter Search - Setup
echo ============================================
echo.
echo Installing required libraries...
pip install pymupdf indic-transliteration rapidfuzz
echo.
echo ============================================
echo  Installation complete!
echo  Launching the app...
echo ============================================
python voter_search.py
pause
