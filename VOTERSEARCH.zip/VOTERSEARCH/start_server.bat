@echo off
title Telugu Voter Search - Server
echo =============================================
echo  Telugu Voter Search - API Server
echo  Keep this window open while using the
echo  Chrome extension.
echo =============================================
echo.
pip install flask flask-cors --quiet
echo Starting server on http://localhost:5005 ...
echo.
python server.py
pause
