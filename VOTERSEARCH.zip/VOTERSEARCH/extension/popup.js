"use strict";

const API = "http://localhost:5005";
const NATIVE_HOST = "com.voter_search.host";
let pollTimer = null;
let previewTimer = null;
let statusPollTimer = null;
let nativeHostAvailable = null; // null = unknown, true/false once determined

// ── DOM refs ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  // Restore saved folder path
  chrome.storage.local.get(["folderPath", "threshold"], data => {
    if (data.folderPath) $("folderInput").value = data.folderPath;
    if (data.threshold)  { $("threshold").value = data.threshold; $("threshVal").textContent = data.threshold + "%"; }
  });

  // Event listeners
  $("retryBtn").addEventListener("click", checkServer);
  $("searchBtn").addEventListener("click", doSearch);
  $("searchInput").addEventListener("keydown", e => { if (e.key === "Enter") doSearch(); });
  $("searchInput").addEventListener("input",   () => schedulePreview());
  $("threshold").addEventListener("input", () => {
    const v = $("threshold").value;
    $("threshVal").textContent = v + "%";
    chrome.storage.local.set({ threshold: v });
  });
  $("settingsToggle").addEventListener("click", toggleSettings);
  $("loadBtn").addEventListener("click", loadIndex);
  $("buildBtn").addEventListener("click", buildIndex);
  $("startBtn").addEventListener("click", startServer);
  $("stopBtn").addEventListener("click", stopServer);

  checkServer();
});

// ── Native messaging helper ─────────────────────────────────────────────────────
function nativeCmd(cmd) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendNativeMessage(NATIVE_HOST, { cmd }, (response) => {
        if (chrome.runtime.lastError) {
          nativeHostAvailable = false;
          console.warn("Native messaging error:", chrome.runtime.lastError.message);
          showControlError(`Native host error: ${chrome.runtime.lastError.message}`);
          resolve(null);
        } else {
          nativeHostAvailable = true;
          hideControlError();
          resolve(response);
        }
      });
    } catch (e) {
      nativeHostAvailable = false;
      showControlError(`Native messaging failed: ${e.message}`);
      resolve(null);
    }
  });
}

function showControlError(text) {
  const el = $("controlError");
  el.textContent = text;
  el.style.display = "block";
}
function hideControlError() {
  $("controlError").style.display = "none";
}

// ── Server check ──────────────────────────────────────────────────────────────
async function checkServer() {
  setStatus("checking");

  const native = await nativeCmd("status");

  if (native && native.running) {
    setStatus("online");
    updateControlBar("running");
    await refreshPingInfo();
  } else if (native && !native.running) {
    setStatus("offline");
    $("mainContent").style.display = "none";
    $("offlineAlert").style.display = "none";
    $("footer").style.display = "none";
    updateControlBar("stopped");
  } else {
    // Native host unavailable — fall back to plain HTTP ping
    try {
      await refreshPingInfo();
      setStatus("online");
      updateControlBar("no-native-online");
    } catch {
      setStatus("offline");
      $("mainContent").style.display = "none";
      $("offlineAlert").style.display = "block";
      $("footer").style.display = "none";
      updateControlBar("no-native-offline");
    }
  }
}

async function refreshPingInfo() {
  const res = await fetch(`${API}/ping`, { signal: AbortSignal.timeout(3000) });
  const data = await res.json();
  $("mainContent").style.display = "block";
  $("offlineAlert").style.display = "none";

  const ocrWarn = $("ocrWarning");
  ocrWarn.style.display = data.ocr ? "none" : "block";

  if (data.entries > 0) {
    const ocrTag = data.ocr ? ` · OCR: ${data.ocr_engine}` : " · ⚠ no OCR";
    showFooter(`${data.entries.toLocaleString()} entries indexed${ocrTag}`);
  }
  return data;
}

function setStatus(state) {
  const dot   = $("statusDot");
  const label = $("statusText");
  dot.className = "dot";
  if (state === "online")   { dot.classList.add("online");  label.textContent = "Server online";  }
  else if (state === "offline") { dot.classList.add("offline"); label.textContent = "Server offline"; }
  else                       { label.textContent = "Connecting…"; }
}

// ── Server Start/Stop controls ──────────────────────────────────────────────────
function updateControlBar(state) {
  const label = $("controlLabel");
  const startBtn = $("startBtn");
  const stopBtn = $("stopBtn");

  if (state === "running") {
    label.textContent = "Server is running";
    startBtn.style.display = "none";
    stopBtn.style.display = "inline-block";
    stopBtn.disabled = false;
  } else if (state === "stopped") {
    label.textContent = "Server is stopped";
    startBtn.style.display = "inline-block";
    startBtn.disabled = false;
    startBtn.textContent = "▶ Start Server";
    stopBtn.style.display = "none";
  } else if (state === "starting") {
    label.textContent = "Starting server… (first load takes ~30s)";
    startBtn.style.display = "inline-block";
    startBtn.disabled = true;
    startBtn.textContent = "Starting…";
    stopBtn.style.display = "none";
  } else if (state === "no-native-online" || state === "no-native-offline") {
    // Native host not installed — hide controls, rely on manual .bat
    label.textContent = "";
    startBtn.style.display = "none";
    stopBtn.style.display = "none";
  }
}

async function startServer() {
  updateControlBar("starting");
  hideControlError();
  const res = await nativeCmd("start");
  if (!res || res.ok === false) {
    updateControlBar("stopped");
    const msg = res && res.error ? res.error : "Failed to start server (native host unreachable — see error above, or reload the extension).";
    showControlError(msg);
    return;
  }
  pollUntilOnline();
}

function pollUntilOnline() {
  clearInterval(statusPollTimer);
  let attempts = 0;
  statusPollTimer = setInterval(async () => {
    attempts++;
    const native = await nativeCmd("status");
    if (native && native.running && !native.starting) {
      clearInterval(statusPollTimer);
      setStatus("online");
      updateControlBar("running");
      try { await refreshPingInfo(); } catch {}
    } else if (attempts > 60) { // ~2 minutes
      clearInterval(statusPollTimer);
      updateControlBar("stopped");
      showControlError("Server did not come online within 2 minutes. Check .host.log in the VOTERSEARCH folder.");
    }
  }, 2000);
}

async function stopServer() {
  $("stopBtn").disabled = true;
  $("stopBtn").textContent = "Stopping…";
  await nativeCmd("stop");
  setStatus("offline");
  $("mainContent").style.display = "none";
  $("offlineAlert").style.display = "none";
  $("footer").style.display = "none";
  updateControlBar("stopped");
}

// ── Telugu live preview ───────────────────────────────────────────────────────
function schedulePreview() {
  clearTimeout(previewTimer);
  const text = $("searchInput").value.trim();
  if (!text) {
    $("teluguPreview").style.display = "none";
    return;
  }
  previewTimer = setTimeout(() => fetchTeluguPreview(text), 400);
}

async function fetchTeluguPreview(text) {
  try {
    const res  = await fetch(`${API}/to_telugu`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
      signal: AbortSignal.timeout(3000),
    });
    const data = await res.json();
    if (data.telugu) {
      $("previewTelugu").textContent = data.telugu;
      // Show "exact" version if different from the smart version
      if (data.telugu_exact && data.telugu_exact !== data.telugu) {
        $("previewAlso").textContent = `(also: ${data.telugu_exact})`;
      } else {
        $("previewAlso").textContent = "";
      }
      $("teluguPreview").style.display = "flex";
    } else {
      $("teluguPreview").style.display = "none";
    }
  } catch {
    $("teluguPreview").style.display = "none";
  }
}

// ── Search ────────────────────────────────────────────────────────────────────
async function doSearch() {
  const query     = $("searchInput").value.trim();
  const threshold = parseInt($("threshold").value);
  if (!query) return;

  $("searchBtn").disabled = true;
  $("searchBtn").textContent = "…";
  $("resultMeta").style.display = "none";
  $("resultsList").innerHTML = "";

  try {
    const res  = await fetch(`${API}/search`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, threshold }),
      signal: AbortSignal.timeout(15000),
    });
    const data = await res.json();

    if (data.error) {
      showMeta(data.error, "none");
    } else {
      renderResults(data.results, query);
    }
  } catch (e) {
    showMeta("Connection error. Is the server running?", "none");
  } finally {
    $("searchBtn").disabled = false;
    $("searchBtn").textContent = "Search";
  }
}

function renderResults(results, query) {
  const list = $("resultsList");
  list.innerHTML = "";

  if (!results.length) {
    showMeta(`No results for "${query}". Try lowering sensitivity.`, "none");
    return;
  }

  showMeta(`${results.length} result${results.length !== 1 ? "s" : ""} for "${query}"`, "found");

  results.forEach(r => {
    const scoreClass = r.score >= 85 ? "score-high" : r.score >= 70 ? "score-mid" : "score-low";
    const item = document.createElement("div");
    item.className = "result-item";

    const refLabel = r.sl_no ? `${r.file} — Sl.No ${r.sl_no}` : `${r.file} — p.${r.page}`;

    const detailBits = [];
    if (r.relation_name) detailBits.push(`<span class="detail-item">👪 ${escHtml(r.relation_name)}</span>`);
    if (r.house_no)      detailBits.push(`<span class="detail-item">🏠 ${escHtml(r.house_no)}</span>`);
    if (r.age)            detailBits.push(`<span class="detail-item">🎂 ${escHtml(r.age)}</span>`);
    if (r.epic_no)        detailBits.push(`<span class="detail-item">🪪 ${escHtml(r.epic_no)}</span>`);

    item.innerHTML = `
      <div class="result-ref-row">
        <span class="result-ref">${escHtml(refLabel)}</span>
        <button class="copy-btn" title="Copy reference" data-ref="${escHtml(refLabel)}">⧉</button>
      </div>
      <div class="result-telugu">${escHtml(r.text)}</div>
      <div class="result-phonetic">${escHtml(r.phonetic)}</div>
      ${detailBits.length ? `<div class="result-details">${detailBits.join("")}</div>` : ""}
      <div class="result-meta-row">
        <span class="result-file" title="${escHtml(r.file)}">📄 ${escHtml(r.file)} — p.${r.page}</span>
        <span class="result-score ${scoreClass}">${r.score}%</span>
      </div>`;

    item.querySelector(".copy-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      navigator.clipboard.writeText(refLabel);
      const btn = e.currentTarget;
      const orig = btn.textContent;
      btn.textContent = "✓";
      setTimeout(() => { btn.textContent = orig; }, 1000);
    });

    list.appendChild(item);
  });
}

function showMeta(text, cls) {
  const el = $("resultMeta");
  el.textContent = text;
  el.className = "result-meta" + (cls ? " " + cls : "");
  el.style.display = "block";
}

// ── Settings panel ────────────────────────────────────────────────────────────
function toggleSettings() {
  const panel = $("settingsPanel");
  const arrow = $("settingsArrow");
  const open  = panel.style.display === "none";
  panel.style.display = open ? "block" : "none";
  arrow.textContent   = open ? "▾" : "▸";
}

async function loadIndex() {
  const folder = $("folderInput").value.trim();
  if (!folder) { setSettingsMsg("Enter a folder path first.", "error"); return; }
  chrome.storage.local.set({ folderPath: folder });

  try {
    const res  = await fetch(`${API}/load`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ folder }),
      signal: AbortSignal.timeout(10000),
    });
    const data = await res.json();
    if (data.error) {
      setSettingsMsg(data.error, "error");
    } else {
      setSettingsMsg(`Loaded ${data.count.toLocaleString()} entries.`, "ok");
      showFooter(`${data.count.toLocaleString()} entries ready`);
    }
  } catch {
    setSettingsMsg("Connection error.", "error");
  }
}

async function buildIndex() {
  const folder = $("folderInput").value.trim();
  if (!folder) { setSettingsMsg("Enter a folder path first.", "error"); return; }
  chrome.storage.local.set({ folderPath: folder });

  $("buildBtn").disabled = true;
  $("buildBtn").textContent = "Building…";
  $("buildProgress").style.display = "block";
  $("progressFill").className = "progress-fill indeterminate";
  setSettingsMsg("", "");

  try {
    const res = await fetch(`${API}/build`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ folder }),
      signal: AbortSignal.timeout(5000),
    });
    const data = await res.json();
    if (data.error) {
      setSettingsMsg(data.error, "error");
      stopBuildUI();
      return;
    }
    // Tell the background worker to watch for completion and notify,
    // even if this popup gets closed before the build finishes.
    chrome.runtime.sendMessage({ type: "build_started" });
    // Poll for progress while the popup stays open
    pollBuild();
  } catch {
    setSettingsMsg("Connection error.", "error");
    stopBuildUI();
  }
}

function pollBuild() {
  clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    try {
      const res  = await fetch(`${API}/build_status`, { signal: AbortSignal.timeout(3000) });
      const data = await res.json();

      if (data.total > 0) {
        const pct = Math.round((data.done / data.total) * 100);
        $("progressFill").className = "progress-fill";
        $("progressFill").style.width = pct + "%";
        $("progressText").textContent = `Processing ${data.done}/${data.total} PDFs…`;
      }

      if (!data.running) {
        clearInterval(pollTimer);
        stopBuildUI();
        if (data.error) {
          setSettingsMsg(data.error, "error");
        } else {
          setSettingsMsg(`Done! ${data.count.toLocaleString()} Telugu entries indexed.`, "ok");
          showFooter(`${data.count.toLocaleString()} entries ready`);
          $("progressFill").style.width = "100%";
        }
      }
    } catch {
      clearInterval(pollTimer);
      stopBuildUI();
      setSettingsMsg("Server disconnected during build.", "error");
    }
  }, 800);
}

function stopBuildUI() {
  $("buildBtn").disabled = false;
  $("buildBtn").textContent = "Build New Index";
  setTimeout(() => { $("buildProgress").style.display = "none"; }, 1500);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function setSettingsMsg(text, cls) {
  const el = $("settingsMsg");
  el.textContent = text;
  el.className = "settings-msg" + (cls ? " " + cls : "");
}

function showFooter(text) {
  $("footer").style.display = "block";
  $("footerText").textContent = text;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
