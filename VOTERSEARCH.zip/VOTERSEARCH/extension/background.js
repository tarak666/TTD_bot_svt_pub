"use strict";

const API = "http://localhost:5005";
const ALARM_NAME = "voterSearchBuildWatch";

chrome.runtime.onInstalled.addListener(setupWatch);
chrome.runtime.onStartup.addListener(setupWatch);

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) checkBuildStatus();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "build_started") {
    chrome.storage.local.set({ buildWasRunning: true });
    setupWatch();
  }
});

function setupWatch() {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
  checkBuildStatus();
}

async function checkBuildStatus() {
  let data;
  try {
    const res = await fetch(`${API}/build_status`, { signal: AbortSignal.timeout(5000) });
    data = await res.json();
  } catch {
    return; // server unreachable right now — try again on next alarm tick
  }

  const store = await chrome.storage.local.get(["buildWasRunning"]);
  const wasRunning = !!store.buildWasRunning;

  if (data.running) {
    if (!wasRunning) await chrome.storage.local.set({ buildWasRunning: true });
    return;
  }

  // Not running now — only notify if it was running last time we checked
  // (avoids firing a notification on a fresh install with no build history).
  if (wasRunning) {
    await chrome.storage.local.set({ buildWasRunning: false });
    const title = data.error ? "Telugu Voter Search — build failed" : "Telugu Voter Search — index ready";
    const message = data.error
      ? data.error
      : `${(data.count || 0).toLocaleString()} Telugu entries indexed and ready to search.`;
    chrome.notifications.create("", {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message,
      priority: 2,
    });
  }
}
