# Registers the Telugu Voter Search native messaging host with Chrome.
# This lets the Chrome extension start/stop/check the local server directly.

$ErrorActionPreference = "Stop"
$baseDir = $PSScriptRoot
$hostName = "com.voter_search.host"
$extensionId = (Get-Content (Join-Path $baseDir "extension_id.txt")).Trim()

# Locate python.exe / pythonw.exe
$pythonExe = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $pythonExe) {
    Write-Host "ERROR: python.exe not found on PATH." -ForegroundColor Red
    exit 1
}
$pythonDir = Split-Path $pythonExe -Parent
$pythonwExe = Join-Path $pythonDir "pythonw.exe"
if (-not (Test-Path $pythonwExe)) { $pythonwExe = $pythonExe }

# 1. Write host.bat wrapper (Chrome native messaging "path" must be a single executable)
$hostBatPath = Join-Path $baseDir "host.bat"
$hostPyPath  = Join-Path $baseDir "host.py"
$hostBatContent = "@echo off`r`n`"$pythonwExe`" `"$hostPyPath`"`r`n"
Set-Content -Path $hostBatPath -Value $hostBatContent -Encoding ASCII -NoNewline
Write-Host "Wrote: $hostBatPath"

# 2. Write native messaging host manifest
$manifestPath = Join-Path $baseDir "native_host_manifest.json"
$manifestObj = [ordered]@{
    name              = $hostName
    description       = "Telugu Voter Search - local server control"
    path              = $hostBatPath
    type              = "stdio"
    allowed_origins   = @("chrome-extension://$extensionId/")
}
$manifestJson = $manifestObj | ConvertTo-Json
# Write without BOM — Chrome's native messaging manifest parser rejects a BOM prefix.
[System.IO.File]::WriteAllText($manifestPath, $manifestJson, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "Wrote: $manifestPath"

# 3. Register in the Windows registry (per-user, no admin needed)
$regPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"
New-Item -Path $regPath -Force | Out-Null
Set-ItemProperty -Path $regPath -Name "(Default)" -Value $manifestPath
Write-Host "Registered native messaging host in: $regPath"

Write-Host ""
Write-Host "============================================================"
Write-Host " Native messaging host installed successfully!"
Write-Host " Extension ID: $extensionId"
Write-Host " Reload the extension at chrome://extensions and try the"
Write-Host " Start/Stop buttons in the popup."
Write-Host "============================================================"
